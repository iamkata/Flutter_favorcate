import 'package:flutter/material.dart';
import 'package:favorcate/core/extension/int_extension.dart';

//最小的操作widget
class HYOperationItem extends StatelessWidget {
  final Widget _icon;
  final String _title;
  final Color textColor; // 可选参数不能以下划线开头

  HYOperationItem(this._icon, this._title, {this.textColor = Colors.black});

  @override
  Widget build(BuildContext context) {
    return Container(
      // 设置固定宽度，防止在收藏和未收藏之间改变的时候，文字宽度的变化导致界面闪动
      width: 80.px,
      // 设置垂直的padding，扩大点击的范围
      padding: EdgeInsets.symmetric(vertical: 12.px),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          _icon,
          SizedBox(width: 3.px,),
          Text(_title, style: TextStyle(color: textColor),)
        ],
      ),
    );
  }
}
