import 'package:favorcate/ui/pages/home/home_app_bar.dart';
import 'package:flutter/material.dart';
import 'home_content.dart';
import 'home_drawer.dart';

class HYHomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // 将mainScreen的context传过去
      appBar: HYHomeAppBar(context),
      body: HYHomeContent(),
      // 如果给HYHomeScreen添加抽屉，那么tabbar不会被盖住，如果想tabbar被盖住，要给HYMainScreen添加抽屉
      // drawer: HYHomeDrawer(),
    );
  }
}
