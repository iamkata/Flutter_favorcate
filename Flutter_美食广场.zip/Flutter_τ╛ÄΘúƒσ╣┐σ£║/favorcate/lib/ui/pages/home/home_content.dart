import 'package:favorcate/core/model/category_model.dart';
import 'package:favorcate/core/services/json_parse.dart';
import 'package:flutter/material.dart';
import 'package:favorcate/core/extension/int_extension.dart';
import 'home_category_item.dart';

class HYHomeContent extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // FutureBuilder可以做到等以后请求到数据的时候，再根据请求的数据来构建界面，而且我们使用StatelessWidget也没事
    return FutureBuilder<List<HYCategoryModel>>(
      // 如果请求数据需要参数，比如上拉刷新，这时候我们就要定义页码再不断加一，这时候使用FutureBuilder就不合适了
      future: HYJsonParse.getCategoryData(),
      builder: (ctx, snapshot) {
        // 没数据就显示转圈
        if (!snapshot.hasData) return Center(child: CircularProgressIndicator());
        // 请求失败就显示失败界面
        if (snapshot.error != null) return Center(child: Text("请求失败"),);

        // 保存数据
        final categories = snapshot.data;
        return GridView.builder(
            padding: EdgeInsets.all(20.px),
            itemCount: categories.length,
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 20.px,
                mainAxisSpacing: 20.px,
                childAspectRatio: 1.5
            ),
            itemBuilder: (ctx, index) {
              return HYHomeCategoryItem(categories[index]);
            }
        );
      },
    );
  }
}
