import 'package:favorcate/ui/pages/detail/detail.dart';
import 'package:favorcate/ui/pages/filter/filter.dart';
import 'package:favorcate/ui/pages/main/main.dart';
import 'package:favorcate/ui/pages/meal/meal.dart';
import 'package:flutter/material.dart';

class HYRouter {
  // 默认的界面
  static final String initialRoute = HYMainScreen.routeName;

  // 配置映射
  static final Map<String, WidgetBuilder> routes = {
    HYMainScreen.routeName: (ctx) => HYMainScreen(),
    HYMealScreen.routeName: (ctx) => HYMealScreen(),
    HYDetailScreen.routeName: (ctx) => HYDetailScreen()
  };

  // 路由钩子
  static final RouteFactory generateRoute = (settings) {
    // 路由拦截过滤界面，然后通过present的方式弹出界面
    if (settings.name == HYFilterScreen.routeName) {
      return MaterialPageRoute(
        builder: (ctx) {
          return HYFilterScreen();
        },
        fullscreenDialog: true
      );
    }

    return null;
  };
  // 未知路由
  static final RouteFactory unknownRoute = (settings) {
    return null;
  };
}